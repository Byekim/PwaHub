﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hub.Model.Voice
{
    public class RequestHomepageLogin
    {
        public string? account { get; set; }
        public string? password { get; set; }
    }
}
