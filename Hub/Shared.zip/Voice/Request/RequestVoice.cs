﻿using Hub.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hub.Model
{
    public class RequestVoice
    {
        public string? aptCd { get; set; }        
        public BroadcastType broadcastType { get; set; }
    }
}
