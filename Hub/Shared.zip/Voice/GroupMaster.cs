﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Hub.Model
{

    public class VoiceBroadcastGroup
    {
        [Required]
        public int groupSeq { get; set; }
        [Required]
        public int seq { get; set; }
        [Required]
        public string aptCd { get; set; }
        
        public GroupMaster groupMaster { get; set; }

    }

    public class GroupMaster 
    {
        [Required]
        public int groupSeq { get; set; }
        [Required]
        public string aptCd { get; set; }
        [Required]
        public string yn { get; set; }
        [Required]
        public string? groupName { get; set; }
        public ICollection<VoiceBroadcastGroup>? VoiceBroadcastGroups { get; set; }

    }
}
