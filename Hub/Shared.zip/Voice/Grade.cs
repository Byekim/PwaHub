﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hub.Model
{
    public class VoiceGrade :RequestVoice
    {
        public string? id { get; set; }        
        //public Hub.Enum.Grade GRADE { get; set; }
    }
}
