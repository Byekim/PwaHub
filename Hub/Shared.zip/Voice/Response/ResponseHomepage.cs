﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hub.Model.Voice.Response
{
    public class ResponseHomepage
    {
        public string? status { get; set; }
        public string? message { get; set; }
    }
}
