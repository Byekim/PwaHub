﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hub.Model
{
    
    public class VoiceNotice
    {
        public int SEQ { get; set; }
        public string? TITLE { get; set; }
        public string? BODY { get; set; }        
        public string? USE { get; set; }
        
    }
}
