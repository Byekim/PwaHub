﻿
using Hub.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hub.Model
{
    public class Reservation : VoiceBroadCast
    {        
        public DateTime reservationTime { get; set; }
        public ReservationType reseravtionType { get; set; }    
    }

    public class SchuledReservation : Reservation
    {
        public string? dayOfWeek { get; set; }
        public string? mon { get; set; }
        public string? tue { get; set; }
        public string? wed { get; set; }
        public string? thu { get; set; }
        public string? fri { get; set; }
        public string? sat { get; set; }
        public string? sun { get; set; }
    }

    public class FromToReservation : Reservation
    {
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
    }
}
