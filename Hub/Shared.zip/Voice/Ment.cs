﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hub.Model
{    
    public class Ment
    {
        public string? firstMent { get; set; }
        public string? middleMent { get; set; }
        public string? endMent { get; set; }
    }
}
