﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hub.Shared.Model.Hub.Login
{
    public class XpErpUserLogin
    {
        public string userStatus { get; set; }
        public string aptCd { get; set; }
        public bool pwFlag { get; set; }
    }
}
