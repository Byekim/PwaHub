﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hub.Shared.Model.Hub.Login;
using Hub.Shared.Model.Hub;

namespace Hub.Shared
{
    public  class GlobalVariable
    {
        private static readonly string _logFileDir = $@"{AppDomain.CurrentDomain.BaseDirectory}Log";
        //public static IConfigurationRoot appSettings => new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true).Build();
        public static readonly string logFileDir = GlobalVariable._logFileDir;

        public static readonly string commonPath = $@"C:\HubAPISetting\CommonSetting.ini";
        public static readonly string commonXperpApiPath = $@"C:\HubAPISetting\XpErpApiSetting.ini";
        public static ResponseBannerData resposneBannerData = new ResponseBannerData() { body = string.Empty, url = string.Empty };
        public static ResponseXperpToken xpErpTokenData = new ResponseXperpToken() { access_token = string.Empty, expires_in = 0, token_type = string.Empty };        //Real
        public static readonly string cognitoClientId = string.Empty;
        public static readonly string cognitoClientSecret = string.Empty;
        public static readonly string cognitoServerAddress = string.Empty;
        public static readonly string xpErpApiServerAddress = string.Empty;
        public static readonly string hubServerApi = @"api/HubLogin/";
        public static readonly string authKey = "aegis12121aegis12121aegis1212100";
        public static readonly int maxIdLength = 5;
    }
}
