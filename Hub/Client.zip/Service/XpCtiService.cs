﻿using Hub.Client.Interface;
using Hub.Client.Model;
using Hub.Shared;

namespace Hub.Client.Service
{
    /// <summary>
    /// XpCtiService
    /// </summary>
    public class XpCtiService : iAdditionalService
    {
        private readonly FileSystemService _fileSystemService;

        public XpCtiService(FileSystemService fileSystemService) 
        {
            _fileSystemService = fileSystemService;
        }

        public AdditionalService additionalService { get; set; } = new AdditionalService
        {
            name = AdditionalServiceName.XpCti,
            imageAddress = @"https://ac.xperp.co.kr/xperp/res/images/ags/Xp통화매니저.png",
            tier = Tier.Tier1,
        };

        public async Task ApplyService()
        {
                    string content = await _fileSystemService.OpenFileAsync();
        Console.WriteLine($"File Content: {content}");

        }
    }

}
