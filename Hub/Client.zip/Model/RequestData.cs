﻿namespace Hub.Client.Model
{
    public class RequestData
    {
        public string data { get; set; }
    }
}
