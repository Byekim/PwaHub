using Hub.Client;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Radzen;
using Microsoft.AspNetCore.SignalR.Client;
using Hub.Client.Service;
using Hub.Client.Interface;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// Radzen �� SignalR ���� ���
builder.Services.AddScoped<DialogService>();
builder.Services.AddScoped<Radzen.NotificationService>();
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });


builder.Services.AddScoped<SignalRService>();

builder.Services.AddApiAuthorization();
builder.Services.AddScoped<FileSystemService>();

builder.Services.AddSingleton<CommonServices>();





// Blazor �� ����
await builder.Build().RunAsync().ContinueWith(task =>
{
    if (task.IsFaulted)
    {
        Console.WriteLine($"Blazor Load Failed: {task.Exception?.Message}");
    }
    else
    {
        Console.WriteLine("Blazor Loaded");
    }
});
