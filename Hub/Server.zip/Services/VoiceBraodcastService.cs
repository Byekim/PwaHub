﻿    using Hub.Model;
using Hub.Server.Interfaces;
using Hub.Server.Models;
using Hub.Shared;

namespace Hub.Server.Services
{
    public class VoiceBraodcastService : iVoiceBroadcast
    {
        private readonly XpVoiceDbContext _dbContext;

        public VoiceBraodcastService(XpVoiceDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AddVoiceBroadcast(VoiceBroadCast voiceBroadcast)
        {
            try
            {
                _dbContext.VoiceBroadCasts.Add(voiceBroadcast);                
                _dbContext.SaveChanges();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public void DeletevoiceBroadcast(VoiceBroadCast pVoiceBroadcast)
        {
            try
            {
                VoiceBroadCast? voiceBroadCast = _dbContext.VoiceBroadCasts.Find(pVoiceBroadcast.seq);
                if (voiceBroadCast != null)
                {
                    _dbContext.VoiceBroadCasts.Remove(voiceBroadCast);
                    _dbContext.SaveChanges();
                }
                else
                {
                    throw new ArgumentNullException();
                }
                
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<VoiceBroadCast> GetAllVoiceBroadcast(string aptCd)
        {
            return _dbContext.VoiceBroadCasts.Where(v => v.aptCd == aptCd).ToList();
        }

        public VoiceBroadCast GetVoiceBroadcast(int seq, string aptCd)
        {
            return _dbContext.VoiceBroadCasts.Where(v => v.aptCd == aptCd && v.seq == seq).FirstOrDefault();
        }

        public void UpdateVoiceBroadcast(VoiceBroadCast voiceBroadcast)
        {
            try
            {
                _dbContext.VoiceBroadCasts.Update(voiceBroadcast);                                 
                _dbContext.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }

        }
    }
}
