﻿using Hub.Model;
using Hub.Shared;

namespace Hub.Server.Interfaces
{
    public interface iVoiceBroadcast
    {
        public void AddVoiceBroadcast(VoiceBroadCast voiceBroadcast);

        public void UpdateVoiceBroadcast(VoiceBroadCast voiceBroadcast);

        public void DeletevoiceBroadcast(VoiceBroadCast pVoiceBroadcast);

        public VoiceBroadCast GetVoiceBroadcast(int seq,string aptCd);

        public List<VoiceBroadCast> GetAllVoiceBroadcast(string aptCd);
    }
}
