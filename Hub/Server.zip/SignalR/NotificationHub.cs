﻿using Hub.Model;
using Hub.Server.Interfaces;
using Hub.Server.Models;
using Hub.Shared;
using Hub.Shared.Model;
using Hub.Shared.Model.Hub;
using Hub.Shared.Model.Hub.Login;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using NetworkLibrary;
using StackExchange.Redis;
using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Hub.Server.SignalR
{
    public class NotificationHub : Hub<iNotifiCationClient>
    {
        private static readonly ConcurrentDictionary<string, ConncectedUser> connectedUsers = new();
        private readonly RedisService _redisService;
        private readonly XpHubDbContext _dbContext;

        public NotificationHub(RedisService redisService, XpHubDbContext dbContext)
        {
            _redisService = redisService;
            _dbContext = dbContext;
        }
        #region Message 
        public async Task SendMessage(string clientId, string data)
        {
            await Clients.Client(clientId).ReceiveNotification(data);
        }

        public async Task BroadcastMessage(string data)
        {
            await Clients.All.ReceiveNotification(data);
        }
        #endregion

        #region Group
        public async Task JoinGroupByCode(string code)
        {
            var user = connectedUsers.Values.FirstOrDefault(u => u.connectionId == Context.ConnectionId);
            if (user != null)
            {
                user.groupName = code;
                await Groups.AddToGroupAsync(Context.ConnectionId, code);
            }
        }

        public async Task LeaveGroupByCode(string code)
        {
            // 그룹에서 사용자를 제거
            var user = connectedUsers.Values.FirstOrDefault(u => u.connectionId == Context.ConnectionId);
            if (user != null && user.groupName == code)
            {
                user.groupName = string.Empty;
                await Groups.RemoveFromGroupAsync(Context.ConnectionId, code);
            }

        }

        public List<ConncectedUser> FindUsersInGroup(string code)
        {
            return connectedUsers.Values.Where(u => u.groupName == code).ToList();
        }
        #endregion

        #region 로그인 로그아웃
        public async Task Login(ResponseXperpLogin login)
        {
            // 사용자 정보를 연결된 사용자에 추가
            var user = connectedUsers.Values.FirstOrDefault(u => u.connectionId == Context.ConnectionId && u.xpErpUserData.userId == login.userId);
            if (user != null)
            {
                user.xpErpUserData = login;
                //await _redisDatabase.StringSetAsync($"user:{user.xpErpUserData.userId}:token",user.connectionId );
                await _dbContext.SaveChangesAsync();
            }
        }
        #endregion
        
        

        
        public override async Task OnConnectedAsync()
        {
            var token = Context.GetHttpContext()?.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
            var userId = await ValidateTokenAsync(token);
            if (string.IsNullOrEmpty(userId))
            {
                Context.Abort();
                return;
            }

            // 연결된 사용자 추가
            var newUser = new ConncectedUser
            {
                connectionId = Context.ConnectionId,
                connctedTime = DateTime.Now,
                xpErpUserData = null
            };

            connectedUsers.TryAdd(Context.ConnectionId, newUser);

            await Clients.Client(Context.ConnectionId).ReceiveNotification($"Thank you Connecting: {Context.User?.Identity?.Name}");
            await base.OnConnectedAsync();
        }


        public override async Task OnDisconnectedAsync(Exception exception)
        {
            if (connectedUsers.TryRemove(Context.ConnectionId, out var user))
            {
                // Redis 및 DB 처리
                await _redisService.RemoveTokenAsync(user.connectionId);
                if (user.xpErpUserData != null)
                {
                    var userTokens = await _dbContext.UserTokens
                        .Where(o => o.userId == user.xpErpUserData.userId)
                        .ToListAsync();
                    _dbContext.UserTokens.RemoveRange(userTokens);
                    await _dbContext.SaveChangesAsync();
                }
                await Clients.Client(user.connectionId).SessionEnded("SessionEnded");
            }
            else
            {
                // 로그 기록
            }

            await base.OnDisconnectedAsync(exception);
        }



        private async Task<string?> ValidateTokenAsync(string? token)
        {
            if (string.IsNullOrEmpty(token)) return null;
            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);

                if (jwtToken.ValidTo < DateTime.UtcNow)
                    return null;

                return jwtToken.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Sub)?.Value;
            }
            catch
            {
                return null;
            }


        }

        public static async Task CheckSessionTimeouts(IHubContext<NotificationHub, iNotifiCationClient> hubContext)
        {
            var now = DateTime.Now;

            foreach (var user in connectedUsers.Values)
            {
                if (now - user.connctedTime > TimeSpan.FromHours(1))
                {
                    // 1시간 이상 활동 없음 -> 연결 끊기
                    await hubContext.Clients.Client(user.connectionId).SessionEnded("Your session has ended.");
                }
            }
        }

        public static List<ConncectedUser> GetConnectedUsers()
        {
            return connectedUsers.Values.ToList();
        }
    }


}


