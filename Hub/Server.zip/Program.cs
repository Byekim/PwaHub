using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;

using Hub.Client;
using Hub.Server.Interfaces;
using Hub.Server.Models;
using Hub.Server.Services;
using Hub.Server.SignalR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Hub.Server;

var builder = WebApplication.CreateBuilder(args);



// Add services to the container
builder.Services.AddTransient<iXpDataHub, XpHubLoginService>();

builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();
builder.Services.AddSignalR(options =>
{
    // �������� Ŭ���̾�Ʈ�� KeepAlive ��ȣ�� ������ ����
    options.KeepAliveInterval = TimeSpan.FromMinutes(10);
    // Ŭ���̾�Ʈ�� ���� ��� �ð� (1�ð�)
    options.ClientTimeoutInterval = TimeSpan.FromHours(1);
});

builder.Services.AddSingleton<TokenService>();


builder.Services.AddEndpointsApiExplorer();

// Background Hosted Service
builder.Services.AddHostedService<ServerTimeNotifier>();
builder.Services.AddHostedService<SessionTimeoutService>();
builder.Services.AddAuthentication("Cookies")
        .AddCookie("Cookies", options =>
        {
            options.Cookie.HttpOnly = true;
            options.Cookie.SameSite = SameSiteMode.None;
            options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        });

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder =>
    {
        builder.WithOrigins("https://localhost:7017")
               .AllowAnyHeader()
               .AllowAnyMethod()
               .AllowCredentials(); // ��Ű ���
    });
});
var app = builder.Build();
app.Use(async (context, next) =>
{
    Console.WriteLine($"Request Path: {context.Request.Path}");
    await next();
});
// Configure the HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseWebAssemblyDebugging();

}
else
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();
app.UseCors("AllowAll"); // CORS ������ �� ���� ȣ��
app.UseHttpsRedirection(); // HTTPS ���𷺼� ����
app.UseBlazorFrameworkFiles();
app.UseStaticFiles();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers(); // API ���� ó��

    endpoints.MapHub<NotificationHub>("/notifications"); // NotificationHub�� UseEndpoints ���� ��ġ��Ŵ
    endpoints.MapFallbackToFile("index.html"); // Blazor SPA ó��
});


app.Run();
