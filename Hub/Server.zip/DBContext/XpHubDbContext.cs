﻿using Microsoft.EntityFrameworkCore;
using Hub.Shared;
using Hub.Model;
using Hub.Shared.Model.Hub.Login;
using Hub.Shared.Model.Hub;

namespace Hub.Server.Models;

public partial class XpHubDbContext : DbContext
{
    
    public virtual DbSet<ResponseXperpToken> tokenDatas { get; set; }
    public DbSet<UserToken> UserTokens { get; set; }

    public XpHubDbContext()
    {
    }

    public XpHubDbContext(DbContextOptions<XpHubDbContext> options)
        : base(options)
    {
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) => optionsBuilder.UseSqlServer("Host=10.0.0.131;Database=DB_HUB;Username=xphub;Password=aegis5539");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        CreateXperpToken(modelBuilder);
        OnModelCreatingPartial(modelBuilder);
    }

    private void CreateXperpToken(ModelBuilder modelBuilder)
    {
        
        modelBuilder.Entity<ResponseXperpToken>(entity =>
        {
            entity.HasKey(e => new { e.access_token })
                  .HasName("PK_H_XPERP_TOKEN");

            entity.ToTable("H_VOICE_BROADCAST");

            entity.Property(e => e.access_token)
                  .HasColumnName("ACCESS_TOKEN")
                  .IsRequired();

            entity.Property(e => e.token_type)
                  .HasColumnName("TOKEN_TYPE");

            entity.Property(e => e.expires_in)
                  .HasColumnName("EXPIREAS_IN");
            
        });

    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
