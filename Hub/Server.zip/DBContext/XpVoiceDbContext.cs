﻿using Microsoft.EntityFrameworkCore;
using Hub.Shared;
using Hub.Model;
using Hub.Shared.Model;

namespace Hub.Server.Models;

public partial class XpVoiceDbContext : DbContext
{
    
    public virtual DbSet<VoiceBroadCast> VoiceBroadCasts { get; set; }
    public virtual DbSet<GroupMaster> GroupMasters { get; set; }
    public virtual DbSet<VoiceBroadCastHistory> VoiceBroadCastHistory { get; set; }
    public virtual DbSet<Reservation> Reservations { get; set; }
    
    
    public XpVoiceDbContext()
    {
    }

    public XpVoiceDbContext(DbContextOptions<XpVoiceDbContext> options)
        : base(options)
    {
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) => optionsBuilder.UseSqlServer("Host=10.0.0.131;Database=DB_HUB;Username=xphub;Password=aegis5539");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {        
        CreateVoiceBroadcast(modelBuilder);
        CreateVoiceBroadcastHistory(modelBuilder);
        CreateVoiceBroadcastGroupMaster(modelBuilder);
        CreateReservationVoiceBroadcast(modelBuilder);
        OnModelCreatingPartial(modelBuilder);
    }

    private void CreateReservationVoiceBroadcast(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Reservation>(entity =>
        {
            entity.HasKey(e => new { e.seq, e.aptCd, e.reservationTime });
            entity.ToTable("H_VOICE_BROADCAST_RESERVATION");
            entity.Property(e => e.aptCd).HasColumnName("APT_CD");
            entity.Property(e => e.seq).HasColumnName("SEQ");
            entity.Property(e => e.reservationTime).HasColumnName("RESERVATION_TIME");
            entity.Property(e => e.reseravtionType).HasColumnName("RESERVATION_TYPE");
            entity.HasDiscriminator<ReservationType>("RESERVATION_TYPE")
                   .HasValue<Reservation>(ReservationType.NORMAL)
                    .HasValue<SchuledReservation>(ReservationType.ROUTINE)
                    .HasValue<FromToReservation>(ReservationType.FROMTO);
        });

        modelBuilder.Entity<SchuledReservation>(entity =>
        {
            entity.HasKey(e => new { e.seq, e.aptCd, e.reservationTime });
            entity.ToTable("H_VOICE_BROADCAST_RESERVATION");
            entity.Property(e => e.aptCd)
                  .HasColumnName("APT_CD");
            entity.Property(e => e.seq)
                  .HasColumnName("SEQ");
            entity.Property(e => e.reservationTime)
                  .HasColumnName("RESERVATION_TIME");
            entity.Property(e => e.reseravtionType)
                  .HasColumnName("RESERVATION_TYPE");
            entity.Property(e => e.mon)
                  .HasColumnName("MON");
            entity.Property(e => e.tue)
                  .HasColumnName("TUE");
            entity.Property(e => e.wed)
                  .HasColumnName("WED");
            entity.Property(e => e.thu)
                  .HasColumnName("THU");
            entity.Property(e => e.fri)
                  .HasColumnName("FRI");
            entity.Property(e => e.sat)
                  .HasColumnName("SAT");
            entity.Property(e => e.sun)
                  .HasColumnName("SUN");
        });


        modelBuilder.Entity<FromToReservation>(entity =>
        {
            entity.HasKey(e => new { e.seq, e.aptCd, e.reservationTime });
            entity.ToTable("H_VOICE_BROADCAST_RESERVATION");
            entity.Property(e => e.aptCd)
                  .HasColumnName("APT_CD");
            entity.Property(e => e.seq)
                  .HasColumnName("SEQ");
            entity.Property(e => e.reservationTime)
                  .HasColumnName("RESERVATION_TIME");
            entity.Property(e => e.reseravtionType)
                  .HasColumnName("RESERVATION_TYPE");
            entity.Property(e => e.startDate)
                  .HasColumnName("START_DATE");
            entity.Property(e => e.endDate)
                  .HasColumnName("END_DATE");

        });

    }




    private void CreateVoiceBroadcastGroupMaster(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<VoiceBroadcastGroup>(entity =>
        {
            entity.HasKey(e => new { e.groupSeq, e.aptCd, e.seq }).HasName("PK_H_VOICE_BROADCAST_GROUP");
            entity.ToTable("H_VOICE_BROADCAST_GROUP");
            entity.Property(e => e.groupSeq).HasColumnName("GROUP_SEQ");
            entity.Property(e => e.aptCd).HasColumnName("APT_CD").HasMaxLength(10);
            entity.Property(e => e.seq).HasColumnName("SEQ");
            entity.HasOne<GroupMaster>()
                  .WithMany(g => g.VoiceBroadcastGroups)
                  .HasForeignKey(e => new { e.groupSeq, e.aptCd })
                  .HasConstraintName("FK_VoiceBroadcastGroup_GroupMaster");
        });


        modelBuilder.Entity<GroupMaster>(entity =>
        {
            entity.HasKey(e => new { e.groupSeq, e.aptCd }).HasName("PK_H_VOICE_BROADCAST_GROUPMASTER");
            entity.ToTable("H_VOICE_BROADCAST_GROUPMASTER");
            entity.Property(e => e.groupSeq).HasColumnName("GROUP_SEQ");
            entity.Property(e => e.aptCd).HasColumnName("APT_CD");
            entity.Property(e => e.groupName).HasColumnName("GROUPNAME");
        });
    }

    private void CreateVoiceBroadcastHistory(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<VoiceBroadCastHistory>(entity =>
        {
            entity.HasKey(e => new { e.historySeq })
                  .HasName("PK_H_VOICE_BROADCAST_HISTORY_1");

            entity.ToTable("H_VOICE_BROADCAST_HISTORY");

            entity.Property(e => e.seq)
                  .HasColumnName("SEQ")
                  .ValueGeneratedOnAdd();

            entity.Property(e => e.aptCd)
                  .HasColumnName("APT_CD")
                  .HasMaxLength(10)
                  .IsRequired();


            entity.Property(e => e.broadcastType)
                  .HasColumnName("BROADCAST_TYPE")
                  .HasMaxLength(20);

            entity.Property(e => e.title)
                  .HasColumnName("TITLE")
                  .HasMaxLength(200);

            entity.Property(e => e.body)
                  .HasColumnName("BODY")
                  .HasMaxLength(4000);

            entity.Property(e => e.speaker)
                  .HasColumnName("SPEAKER")
                  .HasMaxLength(20);

            entity.Property(e => e.historySeq)
                  .HasColumnName("HISTORY_SEQ")
                  .IsRequired();

            entity.Property(e => e.aptI)
                  .HasColumnName("APTI");

        });
    }


    private void CreateVoiceBroadcast(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<VoiceBroadCast>(entity =>
        {
            entity.HasKey(e => new { e.seq, e.aptCd })
                  .HasName("PK_H_VOICE_BROADCAST_1");

            entity.ToTable("H_VOICE_BROADCAST");

            entity.Property(e => e.seq)
                  .HasColumnName("SEQ")
                  .ValueGeneratedOnAdd();

            entity.Property(e => e.aptCd)
                  .HasColumnName("APT_CD")
                  .HasMaxLength(10)
                  .IsRequired();


            entity.Property(e => e.broadcastType)
                  .HasColumnName("BROADCAST_TYPE")
                  .HasMaxLength(20);

            entity.Property(e => e.title)
                  .HasColumnName("TITLE")
                  .HasMaxLength(200);

            entity.Property(e => e.body)
                  .HasColumnName("BODY")
                  .HasMaxLength(4000);

            entity.Property(e => e.speaker)
                  .HasColumnName("SPEAKER")
                  .HasMaxLength(20);


            entity.Property(e => e.inputDate)
                  .HasColumnName("INPUT_DATE")
                  .IsRequired();

            entity.Property(e => e.modifyDate)
                  .HasColumnName("MODIFY_DATE");

            entity.Property(e => e.use)
                  .HasColumnName("USE")
                  .HasDefaultValue('Y')
                  .HasMaxLength(1);

            entity.Property(e => e.bookMark)
                  .HasColumnName("BOOK_MARK")
                  .HasDefaultValue('N')
                  .HasMaxLength(1);

            entity.Property(e => e.voiceSpeed)
                  .HasColumnName("VOICE_SPEED");

            entity.Property(e => e.id)
                  .HasColumnName("ID")
                  .HasMaxLength(100);

            entity.HasOne(e => e.voiceGroup)
                   .WithMany()
                   .HasForeignKey(e => new { e.seq, e.aptCd })
                   .HasConstraintName("FK_VoiceBroadcast_VoiceBroadcastGroup");
        });

    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
